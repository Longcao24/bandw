Actual application screenshots captured on macOS, 2026-10-03.
Python source and captured stdout are displayed in TextEdit. Build stdout is displayed in TextEdit. No board was connected. These images do not document student participation or hardware testing.
